#pragma once
#include "ESP.h"
#include <thread>

void UpdateSpeedhack() {
	void* COW_GameFacade_TypeInfo = *(void**)getAddressIL2CPP(0xB023498);
	if (COW_GameFacade_TypeInfo)
	{
		void* COW_GameFacade_TypeInfo_Fields = *(void**)((uintptr_t)COW_GameFacade_TypeInfo + 0xB8);
		if (COW_GameFacade_TypeInfo_Fields)
		{
			void* CurrentMatchGame = *(void**)((uintptr_t)COW_GameFacade_TypeInfo_Fields + 0x8);
			if (CurrentMatchGame)
			{
				auto TimeService = *(void**)((uintptr_t)CurrentMatchGame + 0x20);
				if (TimeService != nullptr)
				{
					auto Time = *(float*)((uintptr_t)TimeService + 0x2c);
					if (SpeedHack)
					{
						if (Time != 0.065f)
						{
							*(float*)((uintptr_t)TimeService + 0x2c) = 0.065f;
						}

					}
					else {
						if (Time != 0.033f)
						{
							*(float*)((uintptr_t)TimeService + 0x2c) = 0.033f;
						}
					}
				}
			}
		}
	}
}

bool IsVisible(void* closestEnemy) {
	Vector3 Camera = Transform_INTERNAL_GetPosition(Component_GetTransform(Camera_main()));
	Vector3 Collider = Transform_INTERNAL_GetPosition(Component_GetTransform(Player_GetHeadCollider(closestEnemy)));
	HitObjectInfo hitInfo{};
	if (!Physics_Raycast(Camera, Collider, 12, &hitInfo)) {
		return true;
	}
	else {
		if (hitInfo.HitCollider) {
		}
		return false;
	}
}

void* GetClosestEnemy(void* current_Match, void* local_Player) {
	float shortestDistance = MAX_DISTANCE;
	void* closestEnemy = nullptr;
	if (local_Player != nullptr && current_Match != nullptr && Startgs) {
		auto players = *(monoDictionary<uint8_t*, void**>**)((long)current_Match + ListPlayer);
		for (int u = 0; u < players->getNumValues(); u++) {
			void* Player = players->getValues()[u];
			if (Player != nullptr
				&& !get_isLocalTeam(Player)
				&& (ignoreKnockedEnemies || !get_IsDieing(Player))
				&& get_isVisible(Player)
				&& get_MaxHP(Player))
			{
				Vector3 PlayerPos = getPosition(Player);
				Vector3 LocalPlayerPos = getPosition(local_Player);

				float distance = Vector3::Distance(LocalPlayerPos, PlayerPos);
				Vector3 targetDir = Vector3::Normalized(PlayerPos - LocalPlayerPos);
				float angle = Vector3::Angle(targetDir, GetForward(Component_GetTransform(Camera_main()))) * AIM_ANGLE_MULTIPLIER;

				if (distance < Fov && angle < shortestDistance) {
					shortestDistance = angle;
					closestEnemy = Player;
				}
			}
		}
	}
	return closestEnemy;
}

Vector3 GetAdjustedPosition(void* closestEnemy) {
	Vector3 headPos = GetHeadPosition(closestEnemy);
	if (aimPosition == 1) {
		headPos.y += NECK_OFFSET;
	}
	else if (aimPosition == 2) {
		Vector3 hipPos = GetHipPosition(closestEnemy);
		headPos = Vector3::Lerp(headPos, hipPos, 0.5f);
	}
	else if (aimPosition == 3) {
		headPos = GetHipPosition(closestEnemy);
	}
	return headPos;
}

Quaternion GetCameraRotation(void* localPlayer) {
	return GetRotation(Component_GetTransform(Camera_main()));
}

bool IsInFov(Vector3 enemyPos, Vector3 playerPos, float fovLimit) {
	float dx = enemyPos.x - playerPos.x;
	float dy = enemyPos.y - playerPos.y;
	float dz = enemyPos.z - playerPos.z;

	float distance = sqrtf(dx * dx + dy * dy + dz * dz);
	if (distance == 0) return false;

	float angle = acosf(dx / distance) * (360.0f / 3.14159f);
	return angle <= fovLimit;
}

/*
void StartAimkill() {
	if (AimbotEsp && AimKill) {

		float shortestDistance = 99999;

		void* closestEnemy = nullptr;

		{
			void* m_Match = Curent_Match();
			if (m_Match != nullptr)
			{
				void* local_player2 = GetLocalPlayer(m_Match);
				if (local_player2 != nullptr)
				{
					auto Dictionary = *(monoDictionary<uint8_t*, void**> **)((long)m_Match + ListPlayer);
					if (Dictionary != nullptr && Dictionary->getNumValues() > 0)
					{
						for (int u = 0; u < Dictionary->getNumValues(); u++)
						{
							void* PlayerList = Dictionary->getValues()[u];
							if (PlayerList != NULL && !get_isLocalTeam(PlayerList) && (ignoreKnockedEnemies || !get_IsDieing(PlayerList)) && get_isVisible(PlayerList) && get_MaxHP(PlayerList))
							{
								void* LocalHeadTF = GetHeadTF(local_player2);
								void* EnemyHeadTF = GetHeadTF(PlayerList);
								if (EnemyHeadTF != nullptr && LocalHeadTF != nullptr)
								{
									LOGI("closestEnemy");


									Vector3 EnemyHeadPosition = get_position(EnemyHeadTF);
									Vector3 LocalPosition = get_position(LocalHeadTF);

									float distanceToMe = Vector3::Distance(EnemyHeadPosition, LocalPosition);

									if (distanceToMe < shortestDistance)
									{
										shortestDistance = distanceToMe;
										closestEnemy = PlayerList;
									}
								}
							}
						}
						if (closestEnemy != nullptr)
						{
							void* weaponOnHand = GetWeaponOnHand(local_player2);
							if (weaponOnHand != nullptr)
							{
								void* ObjectPool = *(void**)((uintptr_t)local_player2 + m_ObjectPool);
								if (ObjectPool != nullptr)
								{
									void* sla2 = *(void**)((uint64_t)weaponOnHand + m_WeaponData);
									if (sla2 != nullptr)
									{
										auto weaponDataID = *(int32_t*)((uint64_t)sla2 + m_WeaponID);
										auto baseDamage = *(int*)((uintptr_t)weaponOnHand + m_WeaponParams);
										auto playerID = *(COW_GamePlay_IHAAMHPPLMG_o*)((uintptr_t)local_player2 + m_PlayerID);

										void* HeadTFEnemy = GetHeadTF(closestEnemy);
										void* HeadTFLocal = GetHeadTF(local_player2);
										void* HeadColliderEnemy = Player_GetHeadCollider(closestEnemy);
										if (weaponDataID != -1 && baseDamage != 0 && HeadTFEnemy != nullptr && HeadTFLocal != nullptr && HeadColliderEnemy != nullptr)
										{
											Vector3 m_Head = get_position(HeadTFEnemy);
											Vector3 m_HeadLocal = get_position(HeadTFLocal);

											float DistanciaAteJogadorLocal = Vector3::Distance(m_HeadLocal, m_Head);

											void* PlayerAttributes = *(void**)((uint64_t)local_player2 + m_PlayerAttributes);
											if (PlayerAttributes != nullptr)
											{
												void* AHEKHEAHOPP = *(void**)((uint64_t)PlayerAttributes + m_DamageModule);
												if (AHEKHEAHOPP != nullptr)
												{
													void* DamageInfo = *(void**)((uint64_t)AHEKHEAHOPP + m_DamageInfo);
													if (DamageInfo != nullptr)
													{
														*(int*)((char*)DamageInfo + m_BaseDamage) = baseDamage;
														*(int*)((char*)DamageInfo + m_HitColliderType) = 1;
														*(void**)((char*)DamageInfo + m_Weapon) = weaponOnHand;
														*(int*)((char*)DamageInfo + m_WeaponDataID) = weaponDataID;
														*(COW_GamePlay_IHAAMHPPLMG_o*)((char*)DamageInfo + m_PlayerDamager) = playerID;

														*(void**)((uint64_t)ObjectPool + m_HitObject) = get_gameObject(HeadColliderEnemy);
														*(void**)((uint64_t)ObjectPool + m_HitCollider) = HeadColliderEnemy;
														*(int*)((uint64_t)ObjectPool + m_HitGroup) = 1;
														void* sl3 = GetAimingAttackableEntity(local_player2, ObjectPool);
														if (sl3 != nullptr)
														{
															List<float*>* Checkparametros = GenerateCheckParams(weaponOnHand, sl3, HeadColliderEnemy, false, DamageInfo);
															TimerTakeDamageinit++;
															int TipoDaArmaQueEstaSendoUsada = GetTypeWeapon(weaponOnHand);
															if (TipoDaArmaQueEstaSendoUsada == 3)
															{
																if (DistanciaAteJogadorLocal <= 3.0f)
																{
																	if (TimerTakeDamageinit >= 0 && TimerTakeDamageinit <= 10)
																	{
																		((void* (*)(void*, void*))(StartFiring))(local_player2, weaponOnHand);
																		Player_TakeDamage(closestEnemy, baseDamage, playerID, DamageInfo, weaponDataID, m_HeadLocal, m_Head, Checkparametros, Checkparametros, 0);
																	}
																	else {
																		((void* (*)(void*, void*))(StopFire))(local_player2, weaponOnHand);
																	}
																	if (TimerTakeDamageinit >= 25)
																	{
																		TimerTakeDamageinit = 0;
																	}
																}
															}
															else {
																if (TimerTakeDamageinit >= 0 && TimerTakeDamageinit <= 10)
																{
																	((void* (*)(void*, void*))(StartFiring))(local_player2, weaponOnHand);
																	Player_TakeDamage(closestEnemy, baseDamage, playerID, DamageInfo, weaponDataID, m_HeadLocal, m_Head, Checkparametros, Checkparametros, 0);
																}
																else {

																	((void* (*)(void*, void*))(StopFire))(local_player2, weaponOnHand);
																}
																if (TimerTakeDamageinit >= 25) {
																	TimerTakeDamageinit = 0;
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}*/

void AimbotLegitVoid() {
	if (Active && AimbotLegit) {
		void* current_Match = Curent_Match();
		void* local_player = GetLocalPlayer(current_Match);
		void* closestEnemy = GetClosestEnemy(current_Match, local_player);
		if (closestEnemy != NULL && local_player != NULL && current_Match != NULL) {
			void* Current_Collider = *(void**)((uintptr_t)closestEnemy + 0x78);
			void* Head_Collider = Player_GetHeadCollider(closestEnemy);
			if (Current_Collider != Head_Collider) {
				SetAimCollider(closestEnemy, Head_Collider);
			}
		}
	}
}

void AimbotRageVoid() {
    if (Active && AimbotRage) {
        void* current_Match = Curent_Match();
        void* local_player = GetLocalPlayer(current_Match);
        void* closestEnemy = GetClosestEnemy(current_Match, local_player);

        if (closestEnemy != NULL && local_player != NULL && current_Match != NULL) {
            Vector3 enemyLocation = GetAdjustedPosition(closestEnemy);
            Vector3 playerLocation = CameraMain(local_player);

            if (AimVisible && !IsVisible(closestEnemy)) return;
            if (!IsInFov(enemyLocation, playerLocation, Fov)) return;

            Quaternion targetRotation = GetRotationToLocation(enemyLocation, 0.1f, playerLocation);

            bool isScopeOn = get_IsSighting(local_player);
            bool isFiring = get_IsFiring(local_player);

            if (aimbotAuto) {
                set_aim(local_player, targetRotation);
            }
            else if (AimbotRage && isFiring) {
                set_aim(local_player, targetRotation);
            }
            else if (aimbotAim && isScopeOn) {
                set_aim(local_player, targetRotation);
            }
            else if (AimbotRage && aimbotAim && (isFiring || isScopeOn)) {
                set_aim(local_player, targetRotation);
            }
        }
    }
}

/*
static void TakeDamage(void *ClosestEnemy, Vector3 firePos, Vector3 hitPos) {
    if (ClosestEnemy == nullptr) return;
    if (Active && AimKill && IsVisible(ClosestEnemy)) {
        void *LocalPlayer = get_CurrentLocalPlayer();
        if (LocalPlayer != nullptr) {
            void *WeaponHand = get_WeaponOnHand(LocalPlayer);
            if (WeaponHand != nullptr) {
                void* WeaponDataID = get_WeaponData(WeaponHand);
                if (WeaponDataID != nullptr) {
                    void* PlayerAttributes = *(void**)((uint64_t)LocalPlayer + m_PlayerAttributes);
                    if (!PlayerAttributes)
                        return;

                    void* DamageModule = *(void**)((uint64_t)PlayerAttributes + m_DamageModule);
                    if (!DamageModule)
				        return;
                    
                        void* DamageInfo = *(void**)((uint64_t)DamageModule + m_DamageInfo);
                        if (!DamageInfo)
                            return;
                            
                        int DamageCount = get_DamageCount(WeaponHand);
                        PlayerID id = get_PlayerID(LocalPlayer);
                        
                        void* ObjectPool = *(void**)((uintptr_t)LocalPlayer + m_ObjectPool);
                        if (!ObjectPool)
                            return;

                        void* attackInstance = GetAimingAttackableEntity(LocalPlayer, ObjectPool);
                        if (!attackInstance)
                            return;
			            void* HeadColliderEnemy = Player_GetHeadCollider(ClosestEnemy);
                     
                        *(int*)((char*)DamageInfo + m_BaseDamage) = DamageCount;
                        *(int*)((char*)DamageInfo + m_HitCollider) = 1;
                        *(void**)((char*)DamageInfo + m_Weapon) = WeaponHand;
                        *(void**)((char*)DamageInfo + m_WeaponDataID) = WeaponDataID;
                        *(PlayerID*)((char*)DamageInfo + m_PlayerDamager) = id;

                        List<float>* shotParams = GenerateCheckParams(WeaponHand, attackInstance, HeadColliderEnemy, false, DamageInfo);
                        
                        /*
                    if (get_WeaponType(LocalPlayer) != 3 || get_WeaponType(LocalPlayer) == 3) {
                        Network_TakeDamage(ClosestEnemy, DamageCount, id, DamageInfo, *(int *)((uintptr_t) WeaponDataID + (m_WeaponData) 
                        ), firePos, hitPos, *(List<float> *)(shotParams 
                        ), nullptr, 0);
                    }
                    get_StartWholeBodyFiring(LocalPlayer, WeaponHand);*/
                }
            }
        }
    }
}

void StartAimkill() {
    if (Active && AimKill) {
        void* current_Match = Curent_Match();
        void* local_player = GetLocalPlayer(current_Match);
        void* closestEnemy = GetClosestEnemy(current_Match, local_player);

        TakeDamage(closestEnemy, Vector3(get_AttackableCenterWS(local_player).x, get_AttackableCenterWS(local_player).y, get_AttackableCenterWS(local_player).z), Vector3(get_position(get_HeadTF(closestEnemy)).x, get_position(get_HeadTF(closestEnemy)).y, get_position(get_HeadTF(closestEnemy)).z));
    }
}*/

bool(*_ResetGuest)(void* _this);
bool ResetGuest(void* _this) {
	if (_this != NULL) {
		if (ResetGuest1) {
			return true;
			remove(OBFUSCATE("/storage/emulated/0/com.garena.msdk/guest100067.dat"));
		}
	}
}

/*
void HusherAimSilent() {
    while (true) {
	if (AimbotEsp && AimSilent) {
        void* current_Match = Curent_Match();
        void* local_player = GetLocalPlayer(current_Match);
		void* closestEnemy = GetClosestEnemy(current_Match, local_player);
		if (closestEnemy != NULL && current_Match != NULL && local_player != NULL) {
	        void* hitObjInfo = *(void**)((uintptr_t)local_player + m_Silent);
            Vector3 ammoBase = *(Vector3*)((uintptr_t)hitObjInfo + m_Ammo);
	        Vector3 targetHead = GetAdjustedPosition(closestEnemy);
	        if (hitObjInfo && targetHead != Vector3::zero()) {
			    bool isFiring = get_IsFiring(local_player);
				if (isFiring) {
                    bool visible = IsVisible(closestEnemy);
                    if (visible) {
					    *(Vector3*)((uintptr_t)hitObjInfo + m_Bullet) = targetHead - ammoBase;
				    }
                }
			}
		}
	}
    }
}*/

/*
void* GetClosestEnemyToAimkill(void* match, void* local_player) {
	if (!match || !local_player) {
		return nullptr;
	}

	float shortestDistance = 99999.0f;
	void* closestEnemy = nullptr;

	auto players = *(Dictionary<uint8_t*, void**>**)((long)match + ListPlayer);
	if (!players || players->getNumValues() <= 0) {
		return nullptr;
	}

	Vector3 localPos = GetHeadPosition(local_player);

	for (int u = 0; u < players->getNumValues(); u++) {
		void* Player = players->getValues()[u];
		if (!Player) continue;
		if (get_isLocalTeam(Player)) continue;
		if (get_IsDieing(Player)) continue;
		if (!get_MaxHP(Player)) continue;
		if (!IsVisible(Player)) continue;

		Vector3 playerPos = GetHipPosition(Player);
		float distance = Vector3::Distance(localPos, playerPos);

		if (distance < shortestDistance) {
			shortestDistance = distance;
			closestEnemy = Player;
		}
	}

	return closestEnemy;
}

bool saved = false;
void StartAimkill() {
	if (AimbotEsp && AimKill) {

		void* current_Match = Curent_Match();
		if (current_Match) {

			void* local_player = GetLocalPlayer(current_Match);
			if (local_player) {

				Dictionary<uint8_t*, void**>* players = *(Dictionary<uint8_t*, void**>**)((uintptr_t)current_Match + ListPlayer);
				if (players) {

					void* camera = Camera_main();
					if (camera) {

						ImDrawList* drawList = ImGui::GetBackgroundDrawList();
						ImVec2 screenCenter(ImGui::GetIO().DisplaySize.x / 2, 0);

						Vector3 PlayerCameraPosition = getPosition(camera);

						float maxDistance = maxDistanceAimkill;

						void* closestEnemyToAimkill = GetClosestEnemyToAimkill(current_Match, local_player);
						if (!closestEnemyToAimkill)
							return;

						void* weaponOnHand = GetWeaponOnHand(local_player);
						if (!weaponOnHand)
							return;

						void* ObjectPool = *(void**)((uintptr_t)local_player + m_ObjectPool);
						if (!ObjectPool)
							return;

						void* weaponData = *(void**)((uint64_t)weaponOnHand + m_WeaponData);
						if (!weaponData)
							return;

						auto weaponDataID = *(int32_t*)((uint64_t)weaponData + m_WeaponID);
						auto baseDamage = *(int*)((uintptr_t)weaponOnHand + m_WeaponParams);
						auto playerID = *(COW_GamePlay_IHAAMHPPLMG_o*)((uintptr_t)local_player + m_PlayerID);

						void* HeadTFEnemy = GetHeadPositions(closestEnemyToAimkill);
						void* HeadTFLocal = GetHeadPositions(local_player);
						void* HeadColliderEnemy = Player_GetHeadCollider(closestEnemyToAimkill);

						if (weaponDataID == -1 || baseDamage == 0 || !HeadTFEnemy || !HeadTFLocal || !HeadColliderEnemy)
							return;

						Vector3 m_Head = get_position(HeadTFEnemy);
						Vector3 m_HeadLocal = get_position(HeadTFLocal);
						float distanceToEnemy = Vector3::Distance(m_HeadLocal, m_Head);

						if (distanceToEnemy > maxDistance)
							return;

						void* PlayerAttributes = *(void**)((uint64_t)local_player + m_PlayerAttributes);
						if (!PlayerAttributes)
							return;

						void* DamageModule = *(void**)((uint64_t)PlayerAttributes + m_DamageModule);
						if (!DamageModule)
							return;

						WeaponDynamicInfo* dynInfo;
						if (!saved) {
							dynInfo = ReadWeaponDynamicInfo(DamageModule);
							if (!dynInfo) {
								return;
							}
							else {
								saved = true;
							}
						}


						void* DamageInfo = *(void**)((uint64_t)DamageModule + m_DamageInfo);
						if (!DamageInfo)
							return;

						*(int*)((char*)DamageInfo + m_BaseDamage) = baseDamage;
						*(int*)((char*)DamageInfo + m_HitCollider) = 1;
						*(void**)((char*)DamageInfo + m_Weapon) = weaponOnHand;
						*(int*)((char*)DamageInfo + m_WeaponDataID) = weaponDataID;
						*(COW_GamePlay_IHAAMHPPLMG_o*)((char*)DamageInfo + m_PlayerDamager) = playerID;

						*(void**)((uint64_t)ObjectPool + m_HitObject) = get_gameObject(HeadColliderEnemy);
						*(void**)((uint64_t)ObjectPool + m_HitCollider) = HeadColliderEnemy;
						*(int*)((uint64_t)ObjectPool + m_HitGroup) = 1;

						*(float*)((uintptr_t)local_player + 0x684) = 0.0f;
						void* attackInstance = GetAimingAttackableEntity(local_player, ObjectPool);
						if (!attackInstance)
							return;

						List<float*>* shotParams = GenerateCheckParams(weaponOnHand, attackInstance, HeadColliderEnemy, false, DamageInfo);
						TimerTakeDamageinit++;

						if (TimerTakeDamageinit % (rand() % 3 + 5) == 0) {
							int weaponType = GetTypeWeapon(weaponOnHand);

							if (weaponType == 3 && distanceToEnemy <= 3.0f) {
								((void (*)(void*, void*))(StartFiring))(local_player, weaponOnHand);
								Player_TakeDamage(attackInstance, baseDamage, playerID, DamageInfo,
									weaponDataID, m_HeadLocal, m_Head, shotParams, dynInfo, 0);
							}
							else if (weaponType != 3) {
								if (rand() % 10 >= 1) {
									((void (*)(void*, void*))(StartFiring))(local_player, weaponOnHand);
									Player_TakeDamage(attackInstance, baseDamage, playerID, DamageInfo,
										weaponDataID, m_HeadLocal, m_Head, shotParams, dynInfo, 0);
								}
								else {
									((void (*)(void*, void*))(StopFire))(local_player, weaponOnHand);
								}
							}
							else {
								((void (*)(void*, void*))(StopFire))(local_player, weaponOnHand);
							}
						}
						else {
							((void (*)(void*, void*))(StopFire))(local_player, weaponOnHand);
						}

						if (TimerTakeDamageinit >= 15) {
							TimerTakeDamageinit = 0;
						}
					}
				}
			}
			else {
				saved = false;
			}
		}
		else {
			saved = false;
		}
	}
	else {
		saved = false;
	}
}*/
